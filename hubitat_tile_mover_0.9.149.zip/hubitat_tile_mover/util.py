from __future__ import annotations

import os
import sys
from typing import List


def layout_fingerprint(obj: object) -> str:
    """Return a stable fingerprint for the layout content (tiles + custom CSS).

    Used to detect whether a dashboard layout has changed since the last run.
    """
    import hashlib
    import json

    from .css_ops import get_custom_css
    from .jsonio import extract_tiles_container, normalize_tiles_list

    _kind, _container, tiles_any = extract_tiles_container(obj, verbose=False, debug=False)
    tiles = normalize_tiles_list(tiles_any, verbose=False, debug=False)

    def _tile_key(t: dict):
        tid = t.get("id")
        try:
            return (0, int(tid))
        except Exception:
            return (1, str(tid))

    tiles_sorted = sorted([t for t in tiles if isinstance(t, dict)], key=_tile_key)
    _css_key, css = get_custom_css(obj)

    fp_obj = {
        "tiles": tiles_sorted,
        "customCSS": css or "",
    }
    blob = json.dumps(fp_obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _use_color() -> bool:
    """Enable ANSI color on stderr when attached to a TTY (unless NO_COLOR set)."""
    if os.environ.get("NO_COLOR") is not None:
        return False
    return bool(sys.stderr.isatty())


def _c(code: str, s: str) -> str:
    if not _use_color():
        return s
    return f"\x1b[{code}m{s}\x1b[0m"


def err(s: str) -> str:
    return _c("31;1", s)  # bright red


def warn(s: str) -> str:
    return _c("33;1", s)  # bright yellow


def ok(s: str) -> str:
    return _c("32;1", s)  # bright green


def die(msg: str, code: int = 2) -> None:
    print(f"{err('ERROR:')} {msg}", file=sys.stderr)
    raise SystemExit(code)


def wlog(msg: str) -> None:
    print(f"{warn('WARN:')} {msg}", file=sys.stderr, flush=True)


def ilog(msg: str) -> None:
    print(f"INFO: {msg}", file=sys.stderr, flush=True)


def vlog(verbose: bool, msg: str) -> None:
    if verbose:
        print(msg, file=sys.stderr, flush=True)


def dlog(debug: bool, msg: str) -> None:
    if debug:
        print(msg, file=sys.stderr, flush=True)


def normalize_newlines(text: str, mode: str) -> str:
    if mode == "crlf":
        return text.replace("\r\n", "\n").replace("\n", "\r\n")
    if mode == "lf":
        return text.replace("\r\n", "\n")
    return text


def format_id_sample(ids: List[int], max_items: int = 20) -> str:
    ids2 = sorted(ids)
    if len(ids2) <= max_items:
        return ", ".join(map(str, ids2))
    head = ", ".join(map(str, ids2[:max_items]))
    return f"{head}, ... (+{len(ids2) - max_items} more)"


def prompt_yes_no_or_die(
    force: bool,
    prompt: str,
    *,
    what: str = "items",
    details: str | None = None,
    show_details: bool = False,
) -> None:
    if force:
        return
    if not sys.stdin.isatty():
        die(f"This operation affects {what}. Re-run with --force to proceed (no TTY available for prompt).")
    if show_details and details:
        print(details.rstrip() + "\n", file=sys.stderr, flush=True)
    try:
        ans = input(f"{prompt} [y/N]: ").strip().lower()
    except EOFError:
        die(f"This operation affects {what}. Re-run with --force to proceed (no input available).")
    if ans not in ("y", "yes"):
        raise SystemExit(1)


def prompt_yes_no(force: bool, prompt: str, *, default_yes: bool = False) -> bool:
    """Return True/False. If force is True, returns default_yes."""
    if force:
        return default_yes
    try:
        ans = input(f"{prompt} [{'Y/n' if default_yes else 'y/N'}]: ").strip().lower()
    except EOFError:
        return default_yes
    if not ans:
        return default_yes
    if ans in ("y", "yes"):
        return True
    if ans in ("n", "no"):
        return False
    return default_yes
